const s="/images/arthas-web-ui.png";export{s as _};
