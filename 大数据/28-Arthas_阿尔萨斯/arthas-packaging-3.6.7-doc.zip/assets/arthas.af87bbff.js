const s="/images/arthas.png";export{s as _};
