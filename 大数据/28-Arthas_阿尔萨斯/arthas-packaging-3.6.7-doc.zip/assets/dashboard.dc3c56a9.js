const s="/images/dashboard.png";export{s as _};
