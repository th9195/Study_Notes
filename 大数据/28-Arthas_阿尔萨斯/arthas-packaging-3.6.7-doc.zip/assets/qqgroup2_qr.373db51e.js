const s="/images/dingding_qr.jpg",g="/images/dingding2_qr.jpg",_="/images/qqgroup_qr.jpg",i="/images/qqgroup2_qr.jpg";export{s as _,g as a,_ as b,i as c};
