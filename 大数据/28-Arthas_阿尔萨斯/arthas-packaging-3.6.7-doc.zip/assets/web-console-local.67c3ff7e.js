const o="/images/web-console-local.png";export{o as _};
